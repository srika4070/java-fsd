package com.ecommerce;

public class PDescription {

	public String getDescrip() {
		// TODO Auto-generated method stub
		return null;
	}

}
