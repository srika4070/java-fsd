package com.ecommerce;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExternalElements {

	public static void main(String[] args) throws InterruptedException {
		// Basic configuration
		WebDriver driver = new ChromeDriver();
		demoExternalElementsNewTab(driver);
}
static void demoExternalElementsNewTab(WebDriver driver) throws InterruptedException {

		String baseUrl = "File:///C:\\Users\\sri2k\\Phase 5\\External_Elements\\src\\main\\resources\\Hello.html";
		driver.get(baseUrl);


		Thread.sleep(10000);

		driver.switchTo().newWindow(WindowType.TAB);
		driver.navigate().to("https://www.google.com?q=birds");
		
		driver.findElement(By.linkText("See an example alert")).click();

		// alert will appear now, may be in 10 secs
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// Wait for the alert to be displayed
		wait.until(ExpectedConditions.alertIsPresent());

		// Store the alert in a variable
		Alert alert = driver.switchTo().alert();

		System.out.printf("\n alert text is %s \n", alert.getText());

		Thread.sleep(10000);

		alert.accept();
	}




	}


		

