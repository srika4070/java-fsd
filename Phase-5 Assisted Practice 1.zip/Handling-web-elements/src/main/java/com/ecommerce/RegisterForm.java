package com.ecommerce;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class RegisterForm {

	public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.shine.com/registration/");

        WebElement name = driver.findElement(By.id("id_name"));
        name.sendKeys("s");

        WebElement email = driver.findElement(By.id("id_email"));
        email.sendKeys("s@gmail.com");

        WebElement mobile = driver.findElement(By.id("id_cell_phone"));
        mobile.sendKeys("8888888888");

        WebElement password = driver.findElement(By.id("id_password"));
        password.sendKeys("s123");

        WebElement register = driver.findElement(By.cssSelector("#registerButton"));
        register.click();

        //driver.quit();
    }
}
