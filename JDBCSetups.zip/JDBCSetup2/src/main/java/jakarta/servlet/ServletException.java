package jakarta.servlet;

public enum ServletException {

}
